Các bước setup

1. Chạy các file FootballSchedulerDB.sql để cài đặt CSDL cho ứng dụng,
2. Thầy cũng có thể chạy file SampleData.sql để có 1 số dữ liệu mẫu

Tài khoản đăng nhập vào hệ thống:
    Tên đăng nhập: admin
    Mật khẩu: 123456
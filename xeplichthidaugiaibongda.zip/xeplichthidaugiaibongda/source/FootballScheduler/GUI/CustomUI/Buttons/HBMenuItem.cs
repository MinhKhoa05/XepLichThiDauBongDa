﻿namespace GUI.CustomUI.Buttons
{
    public class HBMenuItem : HighlightButton
    {
        public HBMenuItem()
        {
            Active = false;  // Mặc định button không kích hoạt
            Visible = false; // Mặc định button không hiển thị
        }
    }
}

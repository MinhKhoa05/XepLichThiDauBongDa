﻿using System.Windows.Forms;

namespace GUI.UserControls
{
    public partial class UcHome : UserControl
    {
        public UcHome()
        {
            InitializeComponent();
        }
    }
}
